/**
 * Created by lipeiwei on 16/10/5.
 */

//各种类型素材出现的时间

var appearTime = {
  picture: {
    beginYear: 2012,
    beginMonth: 9
  },
  essay: {
    beginYear: 2012,
    beginMonth: 9
  },
  serial: {
    beginYear: 2016,
    beginMonth: 0  //0
  },
  question: {
    beginYear: 2012,
    beginMonth: 9
  },
  music: {
    beginYear: 2016,
    beginMonth: 0
  }
};
export default appearTime;