/**
 * Created by lipeiwei on 16/10/18.
 */


export default CommentType = {
  ESSAY: 'essay',
  SERIAL: 'serial',
  QUESTION: 'question',
  MUSIC: 'music',
  MOVIE: 'movie'
};