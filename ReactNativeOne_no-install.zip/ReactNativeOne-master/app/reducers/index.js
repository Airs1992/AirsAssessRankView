/**
 * Created by lipeiwei on 16/10/14.
 */

import media from './media';
import {combineReducers} from 'redux';



export default combineReducers({
  media
});